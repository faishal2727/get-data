import 'package:dio/dio.dart';

import '../../data/model/restaurant/restaurant.dart';

class RestaurantRepository {
  final Dio _dio = Dio();

  Future<List<Restaurant>> getRestaurants() async {
    try {
      final response = await _dio.get('https://restaurant-api.dicoding.dev/list');
      final data = response.data as List<dynamic>;
      print('$data');
      return data.map((json) => Restaurant.fromJson(json)).toList();
    } catch (error) {
      if (error is DioError) {
        final errorMessage = error.response?.data['message'] ?? 'Failed to load restaurants';
        throw Exception(errorMessage);
      } else {
        throw Exception('Failed to load restaurants');
      }
    }
  }
}

